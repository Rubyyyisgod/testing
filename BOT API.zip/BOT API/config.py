Python 3.14.3 (tags/v3.14.3:323c59a, Feb  3 2026, 16:04:56) [MSC v.1944 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> BOT_TOKEN = "8679267052:AAH-K-Gg7o5H57MFyOMwlBXe-t1WQZO4FjU"
... SMSONAY_BASE_URL = "https://api.ferpay.com.tr/api"
... SMSONAY_EMAIL = "emrtkz4545@gmail.com"
... SMSONAY_PASSWORD = "Emxr2k2k"
... TRONGRID_API_KEY = "8174a489-e39e-440e-8490-7c7145910350"
... ADMIN_IDS = [8229167894, 8235307340]
... PROFIT_MULTIPLIER = 1.5
... MIN_DEPOSIT_USDT = 1.50
... MAIN_WALLET_ADDRESS = "TD8yctEWucQ9MWG3zDJ768wVs5jX2vtkFs"
... SMS_POLL_INTERVAL = 5
... PAYMENT_CHECK_INTERVAL = 10
