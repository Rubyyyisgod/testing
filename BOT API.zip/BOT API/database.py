Python 3.14.3 (tags/v3.14.3:323c59a, Feb  3 2026, 16:04:56) [MSC v.1944 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
import aiosqlite

DB_PATH = "sms_bot.db"


async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.executescript("""
            CREATE TABLE IF NOT EXISTS users (
                user_id         INTEGER PRIMARY KEY,
                username        TEXT,
                full_name       TEXT,
                balance_usdt    REAL DEFAULT 0,
                trx_address     TEXT,
                trx_private_key TEXT,
                created_at      INTEGER DEFAULT (strftime('%s','now'))
            );

            CREATE TABLE IF NOT EXISTS confirmed_txs (
                tx_hash         TEXT PRIMARY KEY,
                user_id         INTEGER,
                trx_amount      REAL,
                usdt_amount     REAL,
                from_address    TEXT,
                confirmed_at    INTEGER DEFAULT (strftime('%s','now'))
            );

            CREATE TABLE IF NOT EXISTS pending_txs (
                tx_hash         TEXT PRIMARY KEY,
                user_id         INTEGER,
                trx_amount      REAL,
                status          TEXT DEFAULT 'pending',
                created_at      INTEGER DEFAULT (strftime('%s','now'))
            );

            CREATE TABLE IF NOT EXISTS orders (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id         INTEGER NOT NULL,
                transaction_id  TEXT NOT NULL,
                phone           TEXT NOT NULL,
                platform_code   TEXT,
                platform_name   TEXT,
                country_code    TEXT,
                country_name    TEXT,
                service_code    TEXT,
                cost_tl         REAL NOT NULL DEFAULT 0,
                cost_usdt       REAL NOT NULL DEFAULT 0,
                status          TEXT DEFAULT 'waiting',
                sms_code        TEXT,
                expires_at      TEXT,
                created_at      INTEGER DEFAULT (strftime('%s','now')),
                FOREIGN KEY(user_id) REFERENCES users(user_id)
            );
        """)
        await db.commit()


async def get_or_create_user(user_id: int, username: str, full_name: str) -> dict:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT OR IGNORE INTO users (user_id, username, full_name) VALUES (?,?,?)",
            (user_id, username, full_name),
        )
        await db.execute(
            "UPDATE users SET username=?, full_name=? WHERE user_id=?",
            (username, full_name, user_id),
        )
        await db.commit()
        async with db.execute("SELECT * FROM users WHERE user_id=?", (user_id,)) as cur:
            row = await cur.fetchone()
            return _row(cur, row)


async def get_user(user_id: int) -> dict | None:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT * FROM users WHERE user_id=?", (user_id,)) as cur:
            row = await cur.fetchone()
            return _row(cur, row) if row else None


async def set_user_wallet(user_id: int, address: str, private_key_encrypted: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE users SET trx_address=?, trx_private_key=? WHERE user_id=?",
            (address, private_key_encrypted, user_id),
        )
        await db.commit()


async def update_balance_usdt(user_id: int, usdt_delta: float):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE users SET balance_usdt = ROUND(balance_usdt + ?, 4) WHERE user_id=?",
            (usdt_delta, user_id),
        )
        await db.commit()


async def get_all_user_addresses() -> list[dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "SELECT user_id, trx_address FROM users WHERE trx_address IS NOT NULL"
        ) as cur:
            rows = await cur.fetchall()
            return [{"user_id": r[0], "trx_address": r[1]} for r in rows]


async def get_all_user_wallets() -> list[dict]:
    """Sweep için adres + şifreli private key döner."""
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "SELECT user_id, trx_address, trx_private_key FROM users WHERE trx_address IS NOT NULL"
        ) as cur:
            rows = await cur.fetchall()
            return [{"user_id": r[0], "trx_address": r[1], "trx_private_key": r[2]} for r in rows]


async def is_tx_confirmed(tx_hash: str) -> bool:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT 1 FROM confirmed_txs WHERE tx_hash=?", (tx_hash,)) as cur:
            return await cur.fetchone() is not None


async def save_confirmed_tx(tx_hash: str, user_id: int, trx_amount: float, usdt_amount: float, from_address: str) -> bool:
    """TX'i kaydet. Daha önce kaydedilmişse False döner (çift işlem önlenir)."""
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT 1 FROM confirmed_txs WHERE tx_hash=?", (tx_hash,)) as cur:
            already = await cur.fetchone()
        if already:
            return False
        await db.execute(
            "INSERT INTO confirmed_txs (tx_hash, user_id, trx_amount, usdt_amount, from_address) VALUES (?,?,?,?,?)",
            (tx_hash, user_id, trx_amount, usdt_amount, from_address),
        )
        await db.commit()
        return True


async def add_pending_tx(tx_hash: str, user_id: int, trx_amount: float):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT OR IGNORE INTO pending_txs (tx_hash, user_id, trx_amount) VALUES (?,?,?)",
            (tx_hash, user_id, trx_amount),
        )
        await db.commit()


async def is_tx_pending(tx_hash: str) -> bool:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT 1 FROM pending_txs WHERE tx_hash=?", (tx_hash,)) as cur:
            return await cur.fetchone() is not None


async def remove_pending_tx(tx_hash: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM pending_txs WHERE tx_hash=?", (tx_hash,))
        await db.commit()


async def create_order(
    user_id: int,
    transaction_id: str,
    phone: str,
    platform_code: str,
    platform_name: str,
    country_code: str,
    country_name: str,
    service_code: str,
    cost_tl: float,
    cost_usdt: float,
    expires_at: str = "",
) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            """INSERT INTO orders
               (user_id, transaction_id, phone, platform_code, platform_name,
                country_code, country_name, service_code, cost_tl, cost_usdt, expires_at)
               VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (
                user_id, transaction_id, phone, platform_code, platform_name,
                country_code, country_name, service_code, cost_tl, cost_usdt, expires_at,
            ),
        ) as cur:
            order_id = cur.lastrowid
        await db.commit()
        return order_id


async def get_order(order_id: int) -> dict | None:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT * FROM orders WHERE id=?", (order_id,)) as cur:
            row = await cur.fetchone()
            return _row(cur, row) if row else None


async def get_order_by_transaction_id(transaction_id: str) -> dict | None:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT * FROM orders WHERE transaction_id=?", (transaction_id,)) as cur:
            row = await cur.fetchone()
            return _row(cur, row) if row else None


async def update_order_status(order_id: int, status: str, sms_code: str = None):
    async with aiosqlite.connect(DB_PATH) as db:
        if sms_code:
            await db.execute("UPDATE orders SET status=?, sms_code=? WHERE id=?", (status, sms_code, order_id))
        else:
            await db.execute("UPDATE orders SET status=? WHERE id=?", (status, order_id))
        await db.commit()


async def update_order_transaction(order_id: int, new_transaction_id: str, new_phone: str):
    """Recreate sonrası yeni transaction ve telefon bilgisi güncelle."""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE orders SET transaction_id=?, phone=?, status='waiting', sms_code=NULL WHERE id=?",
            (new_transaction_id, new_phone, order_id),
        )
        await db.commit()


async def get_waiting_orders() -> list[dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT * FROM orders WHERE status='waiting'") as cur:
            rows = await cur.fetchall()
            cols = [d[0] for d in cur.description]
            return [dict(zip(cols, r)) for r in rows]


async def get_active_orders() -> list[dict]:
    """Waiting + son 24 saatte received olan siparişleri getir (çoklu SMS kontrolü için)."""
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            """SELECT * FROM orders
               WHERE status='waiting'
               OR (status='received' AND created_at > strftime('%s','now') - 86400)"""
        ) as cur:
            rows = await cur.fetchall()
            cols = [d[0] for d in cur.description]
            return [dict(zip(cols, r)) for r in rows]


async def get_user_orders(user_id: int, limit: int = 10) -> list[dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "SELECT * FROM orders WHERE user_id=? ORDER BY created_at DESC LIMIT ?",
            (user_id, limit),
...         ) as cur:
...             rows = await cur.fetchall()
...             cols = [d[0] for d in cur.description]
...             return [dict(zip(cols, r)) for r in rows]
... 
... 
... async def get_all_users() -> list[dict]:
...     async with aiosqlite.connect(DB_PATH) as db:
...         async with db.execute(
...             "SELECT user_id, username, full_name, balance_usdt, trx_address FROM users ORDER BY balance_usdt DESC"
...         ) as cur:
...             rows = await cur.fetchall()
...             cols = [d[0] for d in cur.description]
...             return [dict(zip(cols, r)) for r in rows]
... 
... 
... async def get_stats() -> dict:
...     async with aiosqlite.connect(DB_PATH) as db:
...         stats = {}
...         async with db.execute("SELECT COUNT(*) FROM users") as cur:
...             stats["total_users"] = (await cur.fetchone())[0]
...         async with db.execute("SELECT COUNT(*) FROM orders") as cur:
...             stats["total_orders"] = (await cur.fetchone())[0]
...         async with db.execute("SELECT COUNT(*) FROM orders WHERE status='received'") as cur:
...             stats["success_orders"] = (await cur.fetchone())[0]
...         async with db.execute("SELECT COALESCE(SUM(usdt_amount),0) FROM confirmed_txs") as cur:
...             stats["total_deposit_usdt"] = (await cur.fetchone())[0]
...         async with db.execute("SELECT COALESCE(SUM(cost_usdt),0) FROM orders WHERE status='received'") as cur:
...             stats["total_revenue_usdt"] = (await cur.fetchone())[0]
...         return stats
... 
... 
... def _row(cur, row) -> dict | None:
...     if row is None:
...         return None
