Python 3.14.3 (tags/v3.14.3:323c59a, Feb  3 2026, 16:04:56) [MSC v.1944 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
"""
Sweep Modülü - Sadece TRX
Kullanıcı cüzdanına gelen TRX'i anında ana cüzdana transfer eder.
USDT yok — TRX gelir, bot USDT'ye çevirerek bakiyeye ekler.
"""
import logging
import aiohttp
from tronpy import Tron
from tronpy.keys import PrivateKey
from tronpy.providers import HTTPProvider

from config import TRONGRID_API_KEY, MAIN_WALLET_ADDRESS
from wallet import decrypt_private_key

logger = logging.getLogger(__name__)

_client = Tron(provider=HTTPProvider(
    "https://api.trongrid.io",
    api_key=TRONGRID_API_KEY,
))


async def _get_trx_balance(address: str) -> float:
    """TronGrid REST API ile TRX bakiyesi al."""
    url = f"https://api.trongrid.io/v1/accounts/{address}"
    headers = {"TRON-PRO-API-KEY": TRONGRID_API_KEY}
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get(url, headers=headers, timeout=aiohttp.ClientTimeout(total=10)) as r:
                if r.status != 200:
                    return 0.0
                data = await r.json()
                items = data.get("data", [])
                if not items:
...                     return 0.0
...                 return items[0].get("balance", 0) / 1_000_000
...     except Exception as e:
...         logger.error(f"TRX bakiye hatası {address}: {e}")
...         return 0.0
... 
... 
... async def sweep_wallet(from_address: str, encrypted_private_key: str) -> dict:
...     """
...     Cüzdandaki TRX'i ana cüzdana sweep et.
...     1 TRX gas için bırakılır, geri kalanı gönderilir.
...     """
...     try:
...         balance_trx = await _get_trx_balance(from_address)
...         send_trx = balance_trx - 1.0  # 1 TRX gas için bırak
... 
...         if send_trx < 0.5:
...             logger.info(f"TRX sweep atlandı {from_address}: bakiye düşük ({balance_trx:.2f} TRX)")
...             return {"success": False, "amount": 0, "tx_hash": ""}
... 
...         priv_key_hex = decrypt_private_key(encrypted_private_key)
...         priv_key = PrivateKey(bytes.fromhex(priv_key_hex))
...         send_sun = int(send_trx * 1_000_000)
... 
...         txn = (
...             _client.trx.transfer(from_address, MAIN_WALLET_ADDRESS, send_sun)
...             .memo("sweep")
...             .build()
...             .sign(priv_key)
...         )
...         result = txn.broadcast().wait()
...         tx_hash = result.get("id", "")
...         logger.info(f"TRX sweep OK: {from_address} → {send_trx:.2f} TRX | {tx_hash}")
...         return {"success": True, "amount": send_trx, "tx_hash": tx_hash}
... 
...     except Exception as e:
...         logger.error(f"TRX sweep hatası ({from_address}): {e}")
