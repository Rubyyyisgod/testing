Python 3.14.3 (tags/v3.14.3:323c59a, Feb  3 2026, 16:04:56) [MSC v.1944 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
"""
import asyncio
import aiohttp

SMSONAY_BASE_URL = "https://smsonaylatr.com/api/v1"
EMAIL = "sizin@email.com"      # Kendi emailinizi yazın
PASSWORD = "sifreniz123"        # Kendi şifrenizi yazın


async def test():
    async with aiohttp.ClientSession() as s:
        # 1. Login
        print("=" * 50)
        print("1. LOGIN")
        print("=" * 50)
        try:
            async with s.post(
                f"{SMSONAY_BASE_URL}/auth/v1/login",
                json={"email": EMAIL, "password": PASSWORD, "remember": True},
                headers={"Content-Type": "application/json"},
                timeout=aiohttp.ClientTimeout(total=15),
            ) as r:
                data = await r.json()
                print(f"Status: {r.status}")
                if data.get("token"):
                    token = data["token"]
                    print(f"Token: {token[:30]}...")
                    print(f"User: {data.get('user', {}).get('name')}")
                else:
                    print(f"Hata: {data.get('message')}")
                    return
        except Exception as e:
            print(f"Login hatası: {e}")
            return

        headers = {"Content-Type": "application/json", "Authorization": token}

        # 2. Profil / Bakiye
        print("\n" + "=" * 50)
        print("2. PROFİL & BAKİYE")
        print("=" * 50)
        try:
            async with s.get(f"{SMSONAY_BASE_URL}/user/v1/me", headers=headers) as r:
                data = await r.json()
...                 print(f"İsim: {data.get('name')}")
...                 print(f"Email: {data.get('email')}")
...                 print(f"Bakiye: {data.get('wallet', {}).get('balance')} TL")
...         except Exception as e:
...             print(f"Profil hatası: {e}")
... 
...         # 3. Platformlar (ilk 5)
...         print("\n" + "=" * 50)
...         print("3. PLATFORMLAR (ilk 5)")
...         print("=" * 50)
...         try:
...             async with s.get(f"{SMSONAY_BASE_URL}/sms/v1/platforms", headers=headers) as r:
...                 data = await r.json()
...                 if isinstance(data, list):
...                     print(f"Toplam platform: {len(data)}")
...                     for p in data[:5]:
...                         name = p.get("name", "?")
...                         code = p.get("code", "?")
...                         countries = p.get("countries", [])
...                         print(f"  • {name} ({code}) - {len(countries)} ülke")
...                 else:
...                     print(f"Beklenmeyen yanıt: {data}")
...         except Exception as e:
...             print(f"Platform hatası: {e}")
... 
...         # 4. Ayarlar
...         print("\n" + "=" * 50)
...         print("4. AYARLAR")
...         print("=" * 50)
...         try:
...             async with s.get(f"{SMSONAY_BASE_URL}/settings", headers=headers) as r:
...                 data = await r.json()
...                 print(f"Ayarlar: {data}")
...         except Exception as e:
...             print(f"Ayar hatası: {e}")
... 
... 
