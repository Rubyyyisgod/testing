Python 3.14.3 (tags/v3.14.3:323c59a, Feb  3 2026, 16:04:56) [MSC v.1944 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> import asyncio
... import logging
... 
... from aiogram import Bot, Dispatcher
... from aiogram.fsm.storage.memory import MemoryStorage
... 
... from config import BOT_TOKEN
... from database import init_db
... from handlers import router
... from tasks import start_background_tasks
... 
... logging.basicConfig(
...     level=logging.INFO,
...     format="%(asctime)s  [%(levelname)s]  %(name)s — %(message)s",
...     datefmt="%Y-%m-%d %H:%M:%S"
... )
... 
... async def main():
...     await init_db()
...     bot = Bot(token=BOT_TOKEN)
...     dp = Dispatcher(storage=MemoryStorage())
...     dp.include_router(router)
... 
...     # Arkaplan görevlerini başlat
...     asyncio.create_task(start_background_tasks(bot))
... 
...     logging.info("🚀 SMS Bot v2 başlatıldı.")
...     await dp.start_polling(bot, skip_updates=True)
... 
... if __name__ == "__main__":
