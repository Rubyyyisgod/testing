Python 3.14.3 (tags/v3.14.3:323c59a, Feb  3 2026, 16:04:56) [MSC v.1944 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from config import PROFIT_MULTIPLIER


def main_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📲 Numara Satın Al", callback_data="buy_number")],
        [InlineKeyboardButton(text="🔍 Servis Ara", callback_data="search_service")],
        [
            InlineKeyboardButton(text="💳 Bakiye Yükle", callback_data="deposit"),
            InlineKeyboardButton(text="💰 Bakiyem", callback_data="balance"),
        ],
        [InlineKeyboardButton(text="📋 Siparişlerim", callback_data="my_orders")],
        [InlineKeyboardButton(text="❓ Yardım", callback_data="help")],
    ])


def back_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="« Ana Menü", callback_data="main_menu")]
    ])


def deposit_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔄 Bakiyemi Güncelle", callback_data="refresh_balance")],
        [InlineKeyboardButton(text="« Ana Menü", callback_data="main_menu")],
    ])


def sell_price_tl(cost_tl: float) -> float:
    return cost_tl * PROFIT_MULTIPLIER


def platforms_menu(platforms: list, page: int = 0) -> InlineKeyboardMarkup:
    rows = []
    per_page = 15

    popular_codes = [
        "telegram", "whatsapp", "instagram", "facebook", "google",
        "twitter", "discord", "tiktok", "viber", "vkontakte",
        "amazon", "netflix", "spotify",
    ]

    def sort_key(p):
        code = p.get("code", "")
        if code in popular_codes:
            return (0, popular_codes.index(code))
        return (1, p.get("name", ""))

    sorted_platforms = sorted(platforms, key=sort_key)
    total_pages = max(1, (len(sorted_platforms) + per_page - 1) // per_page)
    start = page * per_page
    end = start + per_page
    page_platforms = sorted_platforms[start:end]

    for p in page_platforms:
        name = p.get("name", p.get("code", "?"))
        code = p.get("code", "")
        country_count = len(p.get("countries", []))
        rows.append([InlineKeyboardButton(
            text=f"{name} • {country_count} ülke",
            callback_data=f"plt_{code}",
        )])

    nav_row = []
    if page > 0:
        nav_row.append(InlineKeyboardButton(text="◀️ Önceki", callback_data=f"plt_page_{page - 1}"))
    if page < total_pages - 1:
        nav_row.append(InlineKeyboardButton(text="Sonraki ▶️", callback_data=f"plt_page_{page + 1}")
    if nav_row:
        rows.append(nav_row)

    rows.append([InlineKeyboardButton(text=f"📄 {page + 1}/{total_pages}", callback_data="ignore")])
    rows.append([InlineKeyboardButton(text="🔍 Servis Ara", callback_data="search_service")])
    rows.append([InlineKeyboardButton(text="« Ana Menü", callback_data="main_menu")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def search_results_menu(results: list) -> InlineKeyboardMarkup:
    rows = []
    for p in results[:20]:
        name = p.get("name", p.get("code", "?"))
        code = p.get("code", "")
        country_count = len(p.get("countries", []))
        rows.append([InlineKeyboardButton(
            text=f"{name} • {country_count} ülke",
            callback_data=f"plt_{code}",
        )])
    rows.append([InlineKeyboardButton(text="📲 Tüm Platformlar", callback_data="buy_number")])
    rows.append([InlineKeyboardButton(text="« Ana Menü", callback_data="main_menu")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def countries_menu(platform_code: str, countries: list, page: int = 0) -> InlineKeyboardMarkup:
    rows = []
    per_page = 12
    total_pages = max(1, (len(countries) + per_page - 1) // per_page)
    start = page * per_page
    end = start + per_page
    page_countries = countries[start:end]

    for c in page_countries:
        from api import country_flag
        flag = country_flag(c.get("alpha2", ""))
        sell = sell_price_tl(c["best_price"])
        rows.append([InlineKeyboardButton(
            text=f"{flag} {c['name']} • {sell:.2f}₺ • {c['best_count']}+",
            callback_data=f"cnt_{platform_code}_{c['code']}",
        )])

    nav_row = []
    if page > 0:
        nav_row.append(InlineKeyboardButton(text="◀️", callback_data=f"cnt_page_{platform_code}_{pae - 1}"))
    if page < total_pages - 1:
        nav_row.append(InlineKeyboardButton(text="▶️", callback_data=f"cnt_page_{platform_code}_{pae + 1}"))
    if nav_row:
        rows.append(nav_row)

    rows.append([InlineKeyboardButton(text="« Platformlar", callback_data="buy_number")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def services_menu(platform_code: str, country_code: str, country_name: str, services: list) -> InlineKeyboardMarkup:
    rows = []
    sorted_services = sorted(services, key=lambda x: x["price"])
    for svc in sorted_services:
        sell = sell_price_tl(svc["price"])
        rows.append([InlineKeyboardButton(
            text=f"📡 {svc['service']} • {sell:.2f}₺ • {svc['count']}+",
            callback_data=f"svc_{platform_code}_{country_code}_{svc['service']}",
        )])
    rows.append([InlineKeyboardButton(text="« Ülkeler", callback_data=f"plt_{platform_code}")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def confirm_order(platform_code: str, country_code: str, service_code: str, sell_price: float) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(
            text=f"✓ Satın Al • {sell_price:.2f}₺",
            callback_data=f"confirm_{platform_code}_{country_code}_{service_code}",
        )],
        [InlineKeyboardButton(text="« Geri", callback_data=f"cnt_{platform_code}_{country_code}")],
...     ])
... 
... 
... def order_actions(transaction_id: str, sms_received: bool = False) -> InlineKeyboardMarkup:
...     tid = transaction_id[:50]
...     if not sms_received:
...         # SMS henüz gelmedi — iptal ve yeni numara var
...         return InlineKeyboardMarkup(inline_keyboard=[
...             [InlineKeyboardButton(text="⏳ SMS Bekleniyor — Kontrol Et", callback_data=f"chk_{tid}")],
...             [InlineKeyboardButton(text="🔁 Yeni Numara Al", callback_data=f"rec_{tid}")],
...             [InlineKeyboardButton(text="❌ İptal Et", callback_data=f"cnl_{tid}")],
...             [InlineKeyboardButton(text="« Ana Menü", callback_data="main_menu")],
...         ])
...     else:
...         return InlineKeyboardMarkup(inline_keyboard=[
...             [InlineKeyboardButton(text="🔄 Tekrar SMS Al", callback_data=f"rec_{tid}")],
...             [InlineKeyboardButton(text="« Ana Menü", callback_data="main_menu")],
...         ])
... 
... 
... def admin_panel() -> InlineKeyboardMarkup:
...     return InlineKeyboardMarkup(inline_keyboard=[
...         [InlineKeyboardButton(text="📊 İstatistikler", callback_data="adm_stats")],
...         [InlineKeyboardButton(text="👥 Kullanıcılar", callback_data="adm_users")],
...         [InlineKeyboardButton(text="📈 Kar Oranı Ayarla", callback_data="adm_profit")],
...         [InlineKeyboardButton(text="💎 SmsOnay Bakiye", callback_data="adm_smsonay")],
...         [InlineKeyboardButton(text="📢 Duyuru", callback_data="adm_broadcast")],
...         [InlineKeyboardButton(text="💳 Bakiye Ver", callback_data="adm_give")],
