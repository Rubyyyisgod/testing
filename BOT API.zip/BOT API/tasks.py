Python 3.14.3 (tags/v3.14.3:323c59a, Feb  3 2026, 16:04:56) [MSC v.1944 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
import asyncio
import logging
import secrets
from datetime import datetime
from aiogram import Bot

import database as db
import api
from sweep import sweep_wallet
from config import PAYMENT_CHECK_INTERVAL, SMS_POLL_INTERVAL

logger = logging.getLogger(__name__)


def gen_tx_id() -> str:
    return secrets.token_urlsafe(9)[:12]


async def _process_tx(bot: Bot, user_id: int, tx: dict, trx_rate: float, usdt_try_rate: float, encrypted_key: str):
    """
    Tek bir işlemi işle:
    1. Bakiyeye ekle
    2. Anında sweep et (ana cüzdana gönder)
    3. Kullanıcıya bildir
    """
    tx_hash = tx["tx_hash"]

    # Çift işlemi önle
    if await db.is_tx_confirmed(tx_hash):
        return

    is_pending = await db.is_tx_pending(tx_hash)
    tronscan_link = f"https://tronscan.org/#/transaction/{tx_hash}"
    tx_id = gen_tx_id()
    coin_type = tx.get("coin_type", "TRX")

    if tx["confirmed"]:
        if coin_type == "USDT":
            usdt_amount = tx["amount_usdt"]
            trx_amount = 0.0
            display_amount = f"{usdt_amount:.2f} USDT"
        else:
            trx_amount = tx["amount_trx"]
            usdt_amount = trx_amount * trx_rate
            display_amount = f"{trx_amount:.2f} TRX ({usdt_amount:.2f} USDT)"

        # Önce TX'i kaydet (çift işlem önlenir)
        saved = await db.save_confirmed_tx(tx_hash, user_id, trx_amount, usdt_amount, tx["from_address"])
        if not saved:
            if is_pending:
                await db.remove_pending_tx(tx_hash)
            return

        # Bakiyeye ekle
        await db.update_balance_usdt(user_id, usdt_amount)

        if is_pending:
            await db.remove_pending_tx(tx_hash)

        # ─── ANINDA SWEEP ───
        user_data = await db.get_user(user_id)
        from_address = user_data.get("trx_address", "")

        sweep_result = None
        if from_address and encrypted_key:
            try:
                sweep_result = await sweep_wallet(from_address, encrypted_key)
                logger.info(f"Sweep tamamlandı user {user_id}: {sweep_result}")
            except Exception as e:
                logger.error(f"Sweep hatası user {user_id}: {e}")
        # ────────────────────

        bal_usdt = user_data.get("balance_usdt", 0)
        bal_try = bal_usdt * usdt_try_rate

        try:
            await bot.send_message(
                user_id,
                f"💵 <b>Cüzdanınıza para girişi oldu.</b> 💵\n\n"
                f"Ticaret ID: {tx_id}\n"
                f"➡️ Yüklenen Miktar: {display_amount}\n"
                f"➡️ Transfer Zamanı: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
                f"➡️ İşlem linki: <a href='{tronscan_link}'>Tıklayın</a>\n\n"
                f"ℹ️ Bakiyeniz Güncellendi:\n"
                f"  ▪️ {bal_usdt:.2f} USDT ({bal_try:.2f} ₺)\n"
                f"  ▪️ Tahmini toplam değer: {bal_try:.2f} ₺",
                parse_mode="HTML",
                disable_web_page_preview=True,
            )
        except Exception as e:
            logger.error(f"Bildirim hatası: {e}")

    elif not is_pending:
        # Henüz onaylanmamış işlem
        if coin_type == "USDT":
            pending_display = f"{tx['amount_usdt']:.2f} USDT"
        else:
            pending_display = f"{tx['amount_trx']:.2f} TRX"

        await db.add_pending_tx(tx_hash, user_id, tx.get("amount_trx", 0))
        try:
            await bot.send_message(
                user_id,
                f"⏳ <b>Hesabınıza {coin_type} yatırılıyor..</b>\n\n"
                f"📑 İşlem numarası: {tx_id}\n"
                f"➡️ Yüklenen Miktar: {pending_display}\n"
                f"➡️ Transfer Zamanı: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
                f"➡️ İşlem linki: <a href='{tronscan_link}'>Tıklayın</a>\n\n"
                f"ℹ️ İşlem ağda onaylandığında hesabınıza yatırılacaktır.",
                parse_mode="HTML",
                disable_web_page_preview=True,
            )
        except:
            pass


async def payment_checker(bot: Bot):
    """TRX ve USDT TRC20 ödemelerini kontrol et, bakiyeye ekle ve sweep et"""
    while True:
        try:
            users = await db.get_all_user_wallets()
            trx_rate = await api.get_trx_to_usdt()
            usdt_try_rate = await api.get_usdt_to_try()

            for user in users:
                user_id = user["user_id"]
                address = user["trx_address"]
                encrypted_key = user.get("trx_private_key", "")

                if not address:
                    continue

                # Sadece TRX transferleri kontrol et
                try:
                    trx_txs = await api.get_incoming_trx(address)
                    for tx in trx_txs:
                        await _process_tx(bot, user_id, tx, trx_rate, usdt_try_rate, encrypted_key)
                except Exception as e:
                    logger.error(f"TRX check hatası user {user_id}: {e}")

                await asyncio.sleep(0.3)

        except Exception as e:
            logger.error(f"Payment checker hatası: {e}")

        await asyncio.sleep(PAYMENT_CHECK_INTERVAL)


async def sms_poller(bot: Bot):
    """Bekleyen ve aktif siparişlerin SMS'lerini SmsOnay API üzerinden kontrol et"""
    while True:
        try:
            orders = await db.get_active_orders()

            for order in orders:
                try:
                    transaction_id = order["transaction_id"]
                    result = await api.check_sms(transaction_id)

                    if result.get("message"):
                        sms_text = result["message"]
                        old_sms = order.get("sms_code") or ""

                        if sms_text != old_sms:
                            await db.update_order_status(order["id"], "received", sms_text)

                            title = "🎉 <b>Yeni SMS Geldi!</b>" if old_sms else "🎉 <b>SMS Geldi!</b>"
                            try:
                                from keyboards import order_actions
                                await bot.send_message(
                                    order["user_id"],
                                    f"{title}\n\n"
                                    f"┌─────────────────────\n"
                                    f"│ 📲 {order.get('platform_name', '')}\n"
                                    f"│ 📱 <code>{order['phone']}</code>\n"
                                    f"│ 🔐 <code>{sms_text}</code>\n"
                                    f"└─────────────────────",
                                    parse_mode="HTML",
                                    reply_markup=order_actions(order["transaction_id"], sms_received=True),
                                )
                            except:
                                pass

                    elif result.get("status") == "banned" and order["status"] == "waiting":
...                         await db.update_order_status(order["id"], "cancelled")
...                         await db.update_balance_usdt(order["user_id"], order["cost_usdt"])
... 
...                         user_data = await db.get_user(order["user_id"])
...                         bal_usdt = user_data.get("balance_usdt", 0)
...                         usdt_try_rate = await api.get_usdt_to_try()
...                         bal_try = bal_usdt * usdt_try_rate
... 
...                         try:
...                             await bot.send_message(
...                                 order["user_id"],
...                                 f"💵 <b>Cüzdanınıza para girişi oldu.</b> 💵\n\n"
...                                 f"➡️ Sipariş #{order['id']} iptal edildi, "
...                                 f"{order.get('cost_tl', 0):.2f} ₺ geri yatırıldı.\n\n"
...                                 f"ℹ️ Bakiyeniz Güncellendi:\n"
...                                 f"  ▪️ {bal_usdt:.2f} USDT ({bal_try:.2f} ₺)",
...                                 parse_mode="HTML",
...                             )
...                         except:
...                             pass
... 
...                 except Exception as e:
...                     logger.error(f"SMS poll hatası (order {order['id']}): {e}")
... 
...                 await asyncio.sleep(0.5)
... 
...         except Exception as e:
...             logger.error(f"SMS poller hatası: {e}")
... 
...         await asyncio.sleep(SMS_POLL_INTERVAL)
... 
... 
... async def start_background_tasks(bot: Bot):
...     asyncio.create_task(payment_checker(bot))
...     asyncio.create_task(sms_poller(bot))
