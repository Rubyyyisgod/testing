Python 3.14.3 (tags/v3.14.3:323c59a, Feb  3 2026, 16:04:56) [MSC v.1944 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
"""
TRX Cüzdan Yönetimi - Her kullanıcıya özel cüzdan oluşturma
"""
import hashlib
import secrets
from typing import Tuple
from cryptography.fernet import Fernet
import base64

from config import ENCRYPTION_KEY

def _get_fernet() -> Fernet:
    """Şifreleme anahtarını hazırla"""
    key = hashlib.sha256(ENCRYPTION_KEY.encode()).digest()
    key_b64 = base64.urlsafe_b64encode(key)
    return Fernet(key_b64)

def encrypt_private_key(private_key: str) -> str:
    """Private key'i şifrele"""
...     f = _get_fernet()
...     return f.encrypt(private_key.encode()).decode()
... 
... def decrypt_private_key(encrypted: str) -> str:
...     """Şifreli private key'i çöz"""
...     f = _get_fernet()
...     return f.decrypt(encrypted.encode()).decode()
... 
... def generate_tron_wallet() -> Tuple[str, str]:
...     """
...     Yeni TRX cüzdan adresi oluştur
...     Returns: (address, private_key)
...     """
...     from tronpy.keys import PrivateKey
... 
...     # Yeni private key oluştur
...     priv_key = PrivateKey.random()
... 
...     # Adres oluştur
...     address = priv_key.public_key.to_base58check_address()
... 
...     return address, priv_key.hex()
... 
... async def get_or_create_wallet(user_id: int, db_module) -> Tuple[str, bool]:
...     """
...     Kullanıcının cüzdanını getir veya yeni oluştur
...     Returns: (address, is_new)
...     """
...     user = await db_module.get_user(user_id)
... 
...     if user and user.get('trx_address'):
...         return user['trx_address'], False
... 
...     # Yeni cüzdan oluştur
...     address, private_key = generate_tron_wallet()
...     encrypted_key = encrypt_private_key(private_key)
... 
...     await db_module.set_user_wallet(user_id, address, encrypted_key)
... 
