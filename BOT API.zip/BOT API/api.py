Python 3.14.3 (tags/v3.14.3:323c59a, Feb  3 2026, 16:04:56) [MSC v.1944 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
import requests

class SmsOnayAPI:
    def __init__(self, email=None, password=None):
        """
        API sınıfını başlatır. E-posta ve şifre verilirse otomatik olarak token alır.
        """
        self.base_url = "https://smsonaylatr.com/api/v1"
        self.session = requests.Session()
        self.session.headers.update({'Content-Type': 'application/json'})
        self.token = None

        if email and password:
            self.login(email, password)

    def check_status(self):
        """API'nin çalışıp çalışmadığını kontrol eder."""
        response = self.session.get(f"{self.base_url}/status")
        return response.json()

    def login(self, email, password):
        """Kullanıcı girişi yapar ve yetkilendirme token'ını ayarlar."""
        url = f"{self.base_url}/auth/createToken"
        payload = {"email": email, "password": password}
        
        response = self.session.post(url, json=payload)
        response.raise_for_status() # HTTP hatası varsa fırlatır
        
        data = response.json()
        if "token" in data:
            self.token = data["token"]
            # Bundan sonraki tüm istekler için Bearer token'ı başlığa ekle
            self.session.headers.update({"Authorization": f"Bearer {self.token}"})
            return self.token
        return data

    # --- SERVİS İŞLEMLERİ ---

    def get_categories(self):
        """Aktif servis kategorilerinin listesini döndürür."""
        url = f"{self.base_url}/service/categories"
        response = self.session.get(url)
        return response.json()

    def get_service_info(self, category_id):
        """Belirli bir kategorideki servisler hakkında detaylı bilgi döndürür."""
        url = f"{self.base_url}/service/info"
        params = {"id": category_id}
        response = self.session.get(url, params=params)
        return response.json()

    def get_service_stock(self, service_id):
        """Belirli bir servisin stok durumunu sorgular."""
        url = f"{self.base_url}/service/stock"
        params = {"id": service_id}
        response = self.session.get(url, params=params)
        return response.json()

    # --- NUMARA İŞLEMLERİ ---

    def buy_number(self, service_id):
        """Belirtilen servisten bir numara satın alır."""
        url = f"{self.base_url}/number/buyNumber"
        payload = {"id": service_id}
        response = self.session.post(url, json=payload)
        return response.json()

    def get_my_numbers(self):
        """Kullanıcının satın aldığı tüm numaraları listeler."""
        url = f"{self.base_url}/number/getNumbers"
        response = self.session.get(url)
        return response.json()

    def cancel_number(self, number_id):
        """Bekleyen bir numarayı iptal eder ve bakiyeyi iade eder."""
        url = f"{self.base_url}/number/cancelNumber"
        payload = {"id": number_id}
        response = self.session.post(url, json=payload)
        return response.json()

...     def extend_number_time(self, number_id):
...         """Türkiye v1 kategorisindeki (OK statüsündeki) numaraların süresini uzatır."""
...         url = f"{self.base_url}/number/extendNumberTime"
...         payload = {"id": number_id}
...         response = self.session.post(url, json=payload)
...         return response.json()
... 
...     def get_sms_list(self, number_id):
...         """Belirli bir numaraya gelen tüm SMS'lerin listesini döndürür."""
...         url = f"{self.base_url}/number/smsList"
...         # API dökümanında belirtilmemiş olsa da genellikle belirli numarayı çekmek için id gönderilir.
...         params = {"id": number_id} 
...         response = self.session.get(url, params=params)
...         return response.json()
... 
... 
... # ==========================================
... # ÖRNEK KULLANIM SENARYOSU
... # ==========================================
... 
... if __name__ == "__main__":
...     # 1. Sınıfı başlatıp giriş yapalım
...     api = SmsOnayAPI(email="user@example.com", password="123456")
...     
...     # 2. Sistem durumunu kontrol edelim
...     print("Sistem Durumu:", api.check_status())
... 
...     # 3. Kategorileri çekelim
...     categories = api.get_categories()
...     print("\nKategoriler:")
...     if categories.get("status"):
...         for category in categories["data"]:
...             print(f"- {category['title']} (ID: {category['id']})")
... 
...     # 4. Türkiye v1 (ID: 1) için servis bilgilerini alalım
...     print("\nServis Bilgileri (Türkiye v1):")
...     service_info = api.get_service_info(category_id=1)
...     print(service_info)

    # 5. Telegram (Örnek Servis ID: 15) stok durumunu kontrol edelim
    print("\nStok Durumu (Telegram):")
    stock_info = api.get_service_stock(service_id=15)
    print(stock_info)

    # 6. Yeni bir numara satın alalım (Örnek Servis ID: 15)
    # print("\nNumara Satın Alınıyor...")
    # buy_result = api.buy_number(service_id=15)
    # print(buy_result)
    
    # 7. Aktif satın aldığım numaraları listeleyelim
    # print("\nNumaralarım:")
    # my_numbers = api.get_my_numbers()
