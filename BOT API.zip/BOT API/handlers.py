Python 3.14.3 (tags/v3.14.3:323c59a, Feb  3 2026, 16:04:56) [MSC v.1944 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
import logging
import secrets
from datetime import datetime
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, BufferedInputFile
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

import database as db
import api
import keyboards as kb
from wallet import get_or_create_wallet
from qr_generator import generate_qr_code
from config import ADMIN_IDS, MIN_DEPOSIT_USDT, PROFIT_MULTIPLIER

logger = logging.getLogger(__name__)
router = Router()


class States(StatesGroup):
    broadcast_msg = State()
    give_balance_uid = State()
    give_balance_amt = State()
    set_profit = State()
    search_query = State()


def is_admin(uid: int) -> bool:
    return uid in ADMIN_IDS


def gen_tx_id() -> str:
    return secrets.token_urlsafe(9)[:12]


async def ensure_user(msg_or_call) -> dict:
    if isinstance(msg_or_call, Message):
        u = msg_or_call.from_user
    else:
        u = msg_or_call.from_user
    return await db.get_or_create_user(u.id, u.username or "", u.full_name or "")


# ══════════════════════════════════════════════════════════════
#  /start
# ══════════════════════════════════════════════════════════════
@router.message(CommandStart())
async def cmd_start(msg: Message, state: FSMContext):
    await state.clear()
    user = await ensure_user(msg)
    bal_usdt = user.get("balance_usdt", 0)
    bal_try = await api.usdt_to_try(bal_usdt)

    await msg.answer(
        f"Hoş geldin <b>{msg.from_user.first_name}</b>! 👋\n\n"
        f"<b>📲 SMS Numara Botu</b>\n"
        f"Telegram, WhatsApp, Google ve 280+ servis için\n"
        f"anında numara al, SMS kodunu hemen gör.\n\n"
        f"ℹ️ <b>Bakiyeniz:</b>\n"
        f"  ▪️ {bal_usdt:.2f} USDT ({bal_try:.2f} ₺)\n\n"
        f"📱 Aşağıdaki menüden işlem seçin:",
        parse_mode="HTML",
        reply_markup=kb.main_menu(),
    )


@router.callback_query(F.data == "main_menu")
async def cb_main_menu(call: CallbackQuery, state: FSMContext):
    await state.clear()
    user = await db.get_user(call.from_user.id)
    bal_usdt = user.get("balance_usdt", 0)
    bal_try = await api.usdt_to_try(bal_usdt)

    try:
        await call.message.delete()
    except:
        pass

    await call.message.answer(
        f"<b>📲 Ana Menü</b>\n\n"
        f"ℹ️ <b>Bakiyeniz:</b>\n"
        f"  ▪️ {bal_usdt:.2f} USDT ({bal_try:.2f} ₺)",
        parse_mode="HTML",
        reply_markup=kb.main_menu(),
    )


@router.callback_query(F.data == "ignore")
async def cb_ignore(call: CallbackQuery):
    await call.answer()


# ══════════════════════════════════════════════════════════════
#  BAKİYEM - MSWAP ŞABLONU
# ══════════════════════════════════════════════════════════════
@router.callback_query(F.data == "balance")
async def cb_balance(call: CallbackQuery):
    user = await db.get_user(call.from_user.id)
    bal_usdt = user.get("balance_usdt", 0)
    trx_rate = await api.get_trx_to_usdt()
    usdt_try_rate = await api.get_usdt_to_try()
    bal_try = bal_usdt * usdt_try_rate

    await call.message.edit_text(
        f"💰 <b>Bakiyeniz</b>\n\n"
        f"ℹ️ Bakiyeniz Güncellendi:\n"
        f"  ▪️ <b>{bal_usdt:.2f} USDT</b> ({bal_try:.2f} ₺)\n\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"📊 <b>Anlık Kurlar</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"  ▪️ 1 TRX = ${trx_rate:.4f} USDT\n"
        f"  ▪️ 1 USDT = {usdt_try_rate:.2f} ₺\n\n"
        f"  ▪️ Tahmini toplam değer: <b>{bal_try:.2f} ₺</b>",
        parse_mode="HTML",
        reply_markup=kb.back_menu(),
    )


# ══════════════════════════════════════════════════════════════
#  BAKİYE YÜKLEME - MSWAP ŞABLONU
# ══════════════════════════════════════════════════════════════
@router.callback_query(F.data == "deposit")
async def cb_deposit(call: CallbackQuery, state: FSMContext):
    await state.clear()
    await call.answer("Cüzdan hazırlanıyor...")

    address, is_new = await get_or_create_wallet(call.from_user.id, db)
    qr_buffer = generate_qr_code(address)

    text = (
        f"Bas kopyala: <code>{address}</code> ✂️\n\n"
        f"Transfer yapmak için yukarıdaki QR kodunu okutabilir "
        f"veya cüzdan adresinin üstüne basarak kopyalayabilirsiniz.\n\n"
        f"💡 <b>Önemli Bilgiler:</b>\n"
        f"✅ Sadece <b>TRX</b> gönderin (TRC20 ağı)\n"
        f"⚠️ USDT veya başka coin göndermeyin, kaybolur!\n"
        f"⚠️ Tek seferde en az {MIN_DEPOSIT_USDT:.2f} USDT değerinde TRX yükleyin.\n"
        f"▪️ Yüklemeler onay aldığında (Yaklaşık 1 dakika) işlenir.\n"
        f"▪️ TRX anlık kur ile USDT'ye çevrilir ve bakiyenize eklenir.\n"
        f"▪️ Size ait bu cüzdan adresinize 7/24 yükleme yapabilirsiniz."
    )

    photo = BufferedInputFile(qr_buffer.read(), filename="qr.png")

    try:
        await call.message.delete()
    except:
        pass

    await call.message.answer_photo(
        photo=photo, caption=text, parse_mode="HTML", reply_markup=kb.deposit_menu()
    )


@router.callback_query(F.data == "refresh_balance")
async def cb_refresh_balance(call: CallbackQuery):
    user = await db.get_user(call.from_user.id)
    bal_usdt = user.get("balance_usdt", 0)
    bal_try = await api.usdt_to_try(bal_usdt)
    await call.answer(
        f"💰 Bakiyeniz: {bal_usdt:.2f} USDT ({bal_try:.2f} ₺)",
        show_alert=True,
    )


# ══════════════════════════════════════════════════════════════
#  SERVİS ARAMA
# ══════════════════════════════════════════════════════════════
@router.callback_query(F.data == "search_service")
async def cb_search_service(call: CallbackQuery, state: FSMContext):
    await state.set_state(States.search_query)
    await call.message.edit_text(
        "🔍 <b>Servis Ara</b>\n\n"
        "Aramak istediğiniz servis adını yazın:\n"
        "<i>Örnek: WhatsApp, Telegram, Instagram...</i>",
        parse_mode="HTML",
        reply_markup=kb.back_menu(),
    )
    await call.answer()


@router.message(States.search_query)
async def msg_search_query(msg: Message, state: FSMContext):
    await state.clear()
    query = msg.text.strip()

    if len(query) < 2:
        await msg.answer("❌ En az 2 karakter girin.", reply_markup=kb.back_menu())
        return

    results = await api.search_platforms(query)

    if not results:
        await msg.answer(
            f"❌ <b>\"{query}\"</b> için sonuç bulunamadı.\n\n"
            f"Farklı bir isim deneyin veya tüm platformları görüntüleyin.",
            parse_mode="HTML",
            reply_markup=kb.search_results_menu([]),
        )
        return

    await msg.answer(
        f"🔍 <b>\"{query}\"</b> için {len(results)} sonuç:\n",
        parse_mode="HTML",
        reply_markup=kb.search_results_menu(results),
    )


# ══════════════════════════════════════════════════════════════
#  NUMARA SATIN ALMA - PLATFORM SEÇİMİ
# ══════════════════════════════════════════════════════════════
@router.callback_query(F.data == "buy_number")
async def cb_buy_number(call: CallbackQuery):
    await call.answer("Platformlar yükleniyor...")
    platforms = await api.get_services_list()

    if not platforms:
        await call.message.edit_text(
            "❌ Platformlar yüklenemedi.\nSmsOnay API'ye bağlanılamadı.",
            reply_markup=kb.back_menu(),
        )
        return

    await call.message.edit_text(
        f"📲 <b>Platform Seçin</b>\n\n"
        f"Fiyatlar <b>TL</b> cinsindendir.\n"
        f"<i>Toplam {len(platforms)} platform mevcut</i>",
        parse_mode="HTML",
        reply_markup=kb.platforms_menu(platforms, page=0),
    )


@router.callback_query(F.data.startswith("plt_page_"))
async def cb_platform_page(call: CallbackQuery):
    page = int(call.data.split("_")[2])
    platforms = await api.get_services_list()
    await call.message.edit_reply_markup(reply_markup=kb.platforms_menu(platforms, page=page))
    await call.answer()


# ══════════════════════════════════════════════════════════════
#  ÜLKE SEÇİMİ
# ══════════════════════════════════════════════════════════════
@router.callback_query(F.data.startswith("plt_") & ~F.data.startswith("plt_page_"))
async def cb_platform_select(call: CallbackQuery):
    platform_code = call.data[4:]
    await call.answer("Ülkeler yükleniyor...")

    countries = await api.get_platform_countries(platform_code)
    if not countries:
        await call.answer("Bu platform için ülke bulunamadı.", show_alert=True)
        return

    platforms = await api.get_services_list()
    platform_name = platform_code
    for p in platforms:
        if p.get("code") == platform_code:
            platform_name = p.get("name", platform_code)
            break

    await call.message.edit_text(
        f"🌍 <b>{platform_name}</b>\n\n"
        f"Ülke seçin (en ucuzdan pahalıya):\n"
        f"<i>Toplam {len(countries)} ülke</i>",
        parse_mode="HTML",
        reply_markup=kb.countries_menu(platform_code, countries, page=0),
    )


@router.callback_query(F.data.startswith("cnt_page_"))
async def cb_country_page(call: CallbackQuery):
    parts = call.data.split("_", 3)
    platform_code = parts[2]
    page = int(parts[3])
    countries = await api.get_platform_countries(platform_code)
    await call.message.edit_reply_markup(
        reply_markup=kb.countries_menu(platform_code, countries, page=page)
    )
    await call.answer()


# ══════════════════════════════════════════════════════════════
#  SERVİS SEÇİMİ
# ══════════════════════════════════════════════════════════════
@router.callback_query(F.data.startswith("cnt_") & ~F.data.startswith("cnt_page_"))
async def cb_country_select(call: CallbackQuery):
    parts = call.data.split("_", 2)
    platform_code = parts[1]
    country_code = parts[2]

    countries = await api.get_platform_countries(platform_code)
    country = None
    for c in countries:
        if c["code"] == country_code:
            country = c
            break

    if not country:
        await call.answer("Ülke bulunamadı.", show_alert=True)
        return

    services = country.get("services", [])

    platforms = await api.get_services_list()
    platform_name = platform_code
    for p in platforms:
        if p.get("code") == platform_code:
            platform_name = p.get("name", platform_code)
            break

    if len(services) == 1:
        svc = services[0]
        sell = kb.sell_price_tl(svc["price"])
        flag = api.country_flag(country.get("alpha2", ""))

        await call.message.edit_text(
            f"📲 <b>{platform_name}</b>\n"
            f"{flag} {country['name']}\n\n"
            f"┌─────────────────────\n"
            f"│ 💵 Fiyat: <b>{sell:.2f} ₺</b>\n"
            f"│ 📦 Stok: {svc['count']}+\n"
            f"└─────────────────────\n\n"
            f"Satın almak için butona tıklayın:",
            parse_mode="HTML",
            reply_markup=kb.confirm_order(platform_code, country_code, svc["service"], sell),
        )
    else:
        await call.message.edit_text(
            f"📡 <b>Servis Seçin</b>\n\n"
            f"{api.country_flag(country.get('alpha2', ''))} {country['name']}\n"
            f"<i>{len(services)} servis seçeneği</i>",
            parse_mode="HTML",
            reply_markup=kb.services_menu(platform_code, country_code, country["name"], services),
        )
    await call.answer()


@router.callback_query(F.data.startswith("svc_"))
async def cb_service_select(call: CallbackQuery):
    parts = call.data.split("_", 3)
    platform_code = parts[1]
    country_code = parts[2]
    service_code = parts[3]

    countries = await api.get_platform_countries(platform_code)
    price_tl = 0
    country_name = ""
    for c in countries:
        if c["code"] == country_code:
            country_name = c["name"]
            for svc in c.get("services", []):
                if svc["service"] == service_code:
                    price_tl = svc["price"]
                    break
            break

    if price_tl == 0:
        await call.answer("Fiyat bilgisi alınamadı.", show_alert=True)
        return

    sell = kb.sell_price_tl(price_tl)

    platforms = await api.get_services_list()
    platform_name = platform_code
    for p in platforms:
        if p.get("code") == platform_code:
            platform_name = p.get("name", platform_code)
            break

    await call.message.edit_text(
        f"📲 <b>{platform_name}</b>\n"
        f"🌍 {country_name}\n"
        f"📡 Servis: {service_code}\n\n"
        f"┌─────────────────────\n"
        f"│ 💵 Fiyat: <b>{sell:.2f} ₺</b>\n"
        f"└─────────────────────\n\n"
        f"Satın almak için butona tıklayın:",
        parse_mode="HTML",
        reply_markup=kb.confirm_order(platform_code, country_code, service_code, sell),
    )
    await call.answer()


# ══════════════════════════════════════════════════════════════
#  SATIN ALMA ONAYI
# ══════════════════════════════════════════════════════════════
@router.callback_query(F.data.startswith("confirm_"))
async def cb_confirm_order(call: CallbackQuery):
    parts = call.data.split("_", 3)
    platform_code = parts[1]
    country_code = parts[2]
    service_code = parts[3]

    user = await db.get_user(call.from_user.id)

    countries = await api.get_platform_countries(platform_code)
    price_tl = 0
    country_name = ""
    alpha2 = ""
    for c in countries:
        if c["code"] == country_code:
            country_name = c["name"]
            alpha2 = c.get("alpha2", "")
            for svc in c.get("services", []):
                if svc["service"] == service_code:
                    price_tl = svc["price"]
                    break
            break

    if price_tl == 0:
        await call.answer("Fiyat alınamadı.", show_alert=True)
        return

    sell_tl = kb.sell_price_tl(price_tl)
    sell_usdt = await api.tl_to_usdt(sell_tl)

    if user.get("balance_usdt", 0) < sell_usdt:
        bal_usdt = user.get("balance_usdt", 0)
        bal_try = await api.usdt_to_try(bal_usdt)
        await call.answer(
            f"❌ Yetersiz bakiye!\n\n"
            f"Gereken: {sell_tl:.2f}₺ ({sell_usdt:.2f} USDT)\n"
            f"Mevcut: {bal_try:.2f}₺ ({bal_usdt:.2f} USDT)",
            show_alert=True,
        )
        return

    await call.answer("Numara alınıyor...")

    platforms = await api.get_services_list()
    platform_name = platform_code
    for p in platforms:
        if p.get("code") == platform_code:
            platform_name = p.get("name", platform_code)
            break

    result = await api.buy_number(platform_code, country_code, service_code)

    if not result:
        await call.message.edit_text("❌ Numara alınamadı.\nSmsOnay API hatası.", reply_markup=kb.back_menu())
        return

    if "error" in result:
        error_map = {
            "sms.error.insufficientFunds": "SmsOnay bakiyesi yetersiz.",
            "sms.error.operatorNotAvailable": "Stok tükendi, başka servis/ülke deneyin.",
            "sms.error.countryNotFound": "Bu ülke şu an aktif değil.",
        }
        error_msg = error_map.get(result["error"], f"Hata: {result['error']}")
        await call.message.edit_text(f"❌ {error_msg}", reply_markup=kb.back_menu())
        return

    await db.update_balance_usdt(call.from_user.id, -sell_usdt)

    order_id = await db.create_order(
        user_id=call.from_user.id,
        transaction_id=result["transaction_id"],
        phone=result["phone"],
        platform_code=platform_code,
        platform_name=platform_name,
        country_code=country_code,
        country_name=country_name,
        service_code=service_code,
        cost_tl=sell_tl,
        cost_usdt=sell_usdt,
        expires_at=result.get("expires_at", ""),
    )

    new_user = await db.get_user(call.from_user.id)
    new_bal = new_user.get("balance_usdt", 0)
    new_bal_try = await api.usdt_to_try(new_bal)

    await call.message.edit_text(
        f"✅ <b>Numara Alındı!</b>\n\n"
        f"┌─────────────────────\n"
        f"│ 📲 {platform_name}\n"
        f"│ {api.country_flag(alpha2)} {country_name}\n"
        f"│ 📱 <code>{result['phone']}</code>\n"
        f"│ 💵 {sell_tl:.2f} ₺\n"
        f"│ 🎫 #{order_id}\n"
        f"└─────────────────────\n\n"
        f"ℹ️ Bakiyeniz Güncellendi:\n"
        f"  ▪️ {new_bal:.2f} USDT ({new_bal_try:.2f} ₺)\n\n"
        f"⏳ SMS bekleniyor...",
        parse_mode="HTML",
        reply_markup=kb.order_actions(result["transaction_id"]),
    )


# ══════════════════════════════════════════════════════════════
#  SMS KONTROL
# ══════════════════════════════════════════════════════════════
@router.callback_query(F.data.startswith("chk_"))
async def cb_check_sms(call: CallbackQuery):
    transaction_id = call.data[4:]
    order = await db.get_order_by_transaction_id(transaction_id)
    if not order or order["user_id"] != call.from_user.id:
        await call.answer("Sipariş bulunamadı.", show_alert=True)
        return

    # Her zaman API'den tekrar kontrol et (2. SMS gelebilir)
    result = await api.check_sms(transaction_id)

    if result.get("message"):
        sms_text = result["message"]
        old_sms = order.get("sms_code") or ""

        if sms_text != old_sms:
            # Yeni SMS geldi
            await db.update_order_status(order["id"], "received", sms_text)
            title = "🎉 <b>Yeni SMS Geldi!</b>" if old_sms else "🎉 <b>SMS Geldi!</b>"
            await call.message.edit_text(
                f"{title}\n\n"
                f"┌─────────────────────\n"
                f"│ 📲 {order.get('platform_name', '')}\n"
                f"│ 📱 <code>{order['phone']}</code>\n"
                f"│ 🔐 <code>{sms_text}</code>\n"
                f"└─────────────────────\n\n"
                f"2. SMS beklemek için '🔄 2. SMS Kontrol Et' butonuna basın.",
                parse_mode="HTML",
                reply_markup=kb.order_actions(transaction_id, sms_received=True),
            )
        else:
            # Aynı SMS tekrar geldi, popup göster
            await call.answer(f"✅ Mevcut Kod: {sms_text}", show_alert=True)
    elif result.get("status") == "banned":
        await call.answer("❌ Numara iptal edildi.", show_alert=True)
    else:
        await call.answer("⏳ SMS henüz gelmedi. Birkaç saniye bekleyin.", show_alert=True)


# ══════════════════════════════════════════════════════════════
#  SİPARİŞ İPTAL
# ══════════════════════════════════════════════════════════════
@router.callback_query(F.data.startswith("cnl_"))
async def cb_cancel(call: CallbackQuery):
    transaction_id = call.data[4:]
    order = await db.get_order_by_transaction_id(transaction_id)
    if not order or order["user_id"] != call.from_user.id:
        await call.answer("Sipariş bulunamadı.", show_alert=True)
        return

    if order["status"] != "waiting":
        await call.answer("İptal edilemez.", show_alert=True)
        return

    result = await api.cancel_order(transaction_id)
    if result.get("success"):
        await db.update_order_status(order["id"], "cancelled")
        await db.update_balance_usdt(call.from_user.id, order["cost_usdt"])

        user = await db.get_user(call.from_user.id)
        bal_usdt = user.get("balance_usdt", 0)
        bal_try = await api.usdt_to_try(bal_usdt)

        await call.message.edit_text(
            f"💵 <b>Cüzdanınıza para girişi oldu.</b> 💵\n\n"
            f"➡️ İptal edildi, {order['cost_tl']:.2f} ₺ geri yatırıldı.\n\n"
            f"ℹ️ Bakiyeniz Güncellendi:\n"
            f"  ▪️ {bal_usdt:.2f} USDT ({bal_try:.2f} ₺)",
            parse_mode="HTML",
            reply_markup=kb.back_menu(),
        )
    else:
        await call.answer("İptal başarısız.", show_alert=True)


# ══════════════════════════════════════════════════════════════
#  YENİ NUMARA (RECREATE)
# ══════════════════════════════════════════════════════════════
@router.callback_query(F.data.startswith("rec_"))
async def cb_recreate(call: CallbackQuery):
    transaction_id = call.data[4:]
    order = await db.get_order_by_transaction_id(transaction_id)
    if not order or order["user_id"] != call.from_user.id:
        await call.answer("Sipariş bulunamadı.", show_alert=True)
        return

    await call.answer("Yeni numara alınıyor...")
    result = await api.recreate_number(transaction_id)

    if not result:
        await call.answer("Yeni numara alınamadı.", show_alert=True)
        return

    # Yeni transaction ve telefonu kaydet, waiting'e al
    await db.update_order_transaction(order["id"], result["transaction_id"], result["phone"])

    await call.message.edit_text(
        f"🔁 <b>Yeni Numara Alındı!</b>\n\n"
        f"┌─────────────────────\n"
        f"│ 📲 {order.get('platform_name', '')}\n"
        f"│ 📱 <code>{result['phone']}</code>\n"
        f"│ 🎫 #{order['id']}\n"
        f"└─────────────────────\n\n"
        f"⏳ SMS bekleniyor...",
        parse_mode="HTML",
        reply_markup=kb.order_actions(result["transaction_id"], sms_received=False),
    )


# ══════════════════════════════════════════════════════════════
#  SİPARİŞLERİM
# ══════════════════════════════════════════════════════════════
@router.callback_query(F.data == "my_orders")
async def cb_orders(call: CallbackQuery):
    orders = await db.get_user_orders(call.from_user.id)
    if not orders:
        await call.message.edit_text("📋 Sipariş yok.", reply_markup=kb.back_menu())
        return

    emoji = {"waiting": "⏳", "received": "✅", "cancelled": "❌"}
    lines = ["📋 <b>Siparişler</b>\n"]

    for o in orders:
        e = emoji.get(o["status"], "❓")
        line = f"{e} #{o['id']} | {o.get('platform_name', '')} | <code>{o['phone']}</code> | {o.get('cost_tl', 0):.2f}₺"
        if o.get("sms_code"):
            line += f"\n🔐 <code>{o['sms_code']}</code>"
        lines.append(line)

    await call.message.edit_text("\n\n".join(lines), parse_mode="HTML", reply_markup=kb.back_menu())


# ══════════════════════════════════════════════════════════════
#  YARDIM
# ══════════════════════════════════════════════════════════════
@router.callback_query(F.data == "help")
async def cb_help(call: CallbackQuery):
    await call.message.edit_text(
        "❓ <b>Yardım</b>\n\n"
        "<b>1. Bakiye Yükle</b>\n"
        "TRX veya USDT gönderin → Otomatik bakiyeye eklenir\n\n"
        "<b>2. Numara Al</b>\n"
        "Platform → Ülke → Servis seç, otomatik satın al\n\n"
        "<b>3. Servis Ara</b>\n"
        "İstediğiniz servisi ismiyle arayın\n\n"
        "<b>4. SMS Bekle</b>\n"
        "Kod gelince bildirim alırsınız\n\n"
        "<b>5. Yeni Numara</b>\n"
        "SMS gelmezse aynı siparişten yeni numara alın\n\n"
        "📱 <b>280+ platform</b> desteklenir!",
        parse_mode="HTML",
        reply_markup=kb.back_menu(),
    )


# ══════════════════════════════════════════════════════════════
#  ADMİN PANELİ
# ══════════════════════════════════════════════════════════════
@router.message(Command("admin"))
async def cmd_admin(msg: Message):
    if not is_admin(msg.from_user.id):
        return
    await msg.answer("🔧 <b>Admin Paneli</b>", parse_mode="HTML", reply_markup=kb.admin_panel())


@router.callback_query(F.data == "adm_stats")
async def cb_adm_stats(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return
    s = await db.get_stats()
    smsonay_bal = await api.get_balance()
    trx_rate = await api.get_trx_to_usdt()
    usdt_try = await api.get_usdt_to_try()
    profit_pct = (PROFIT_MULTIPLIER - 1) * 100

    await call.message.edit_text(
        f"📊 <b>İstatistikler</b>\n\n"
        f"👥 Kullanıcı: {s['total_users']}\n"
        f"📱 Sipariş: {s['total_orders']}\n"
        f"✅ Başarılı: {s['success_orders']}\n\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"💵 Toplam Yatırım: ${s['total_deposit_usdt']:.2f}\n"
        f"💰 Toplam Gelir: ${s['total_revenue_usdt']:.2f}\n"
        f"🔷 SmsOnay: {smsonay_bal:.2f}₺\n\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"⚙️ Kar Oranı: %{profit_pct:.0f}\n"
        f"📈 TRX/USDT: ${trx_rate:.4f}\n"
        f"📈 USDT/TRY: {usdt_try:.2f}₺",
        parse_mode="HTML",
        reply_markup=kb.admin_panel(),
    )


@router.callback_query(F.data == "adm_users")
async def cb_adm_users(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return
    users = await db.get_all_users()
    lines = [f"👥 <b>Kullanıcılar ({len(users)})</b>\n"]
    for u in users[:15]:
        name = f"@{u['username']}" if u.get("username") else str(u["user_id"])
        lines.append(f"• {name} — ${u.get('balance_usdt', 0):.4f}")
    await call.message.edit_text("\n".join(lines), parse_mode="HTML", reply_markup=kb.admin_panel())


@router.callback_query(F.data == "adm_smsonay")
async def cb_adm_smsonay(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return
    bal = await api.get_balance()
    await call.answer(f"SmsOnay: {bal:.2f}₺", show_alert=True)


@router.callback_query(F.data == "adm_profit")
async def cb_adm_profit(call: CallbackQuery, state: FSMContext):
    if not is_admin(call.from_user.id):
        return
    profit_pct = (PROFIT_MULTIPLIER - 1) * 100
    await state.set_state(States.set_profit)
    await call.message.edit_text(
        f"📈 <b>Kar Oranı Ayarla</b>\n\nŞu anki: <b>%{profit_pct:.0f}</b>\n\n"
        f"Yeni oranı yüzde olarak girin:\n(Örnek: 100 = %100 kar)",
        parse_mode="HTML",
        reply_markup=kb.back_menu(),
    )


@router.message(States.set_profit)
async def msg_set_profit(msg: Message, state: FSMContext):
    if not is_admin(msg.from_user.id):
        return
    try:
        pct = float(msg.text.replace(",", ".").replace("%", ""))
        new_mult = 1 + (pct / 100)
        with open("config.py", "r") as f:
            content = f.read()
        import re
        content = re.sub(r"PROFIT_MULTIPLIER\s*=\s*[\d.]+", f"PROFIT_MULTIPLIER = {new_mult}", content)
        with open("config.py", "w") as f:
            f.write(content)
        import config
        config.PROFIT_MULTIPLIER = new_mult
        await state.clear()
        await msg.answer(f"✅ Kar oranı %{pct:.0f} olarak ayarlandı!")
    except:
        await msg.answer("❌ Geçersiz değer")


@router.callback_query(F.data == "adm_broadcast")
async def cb_adm_broadcast(call: CallbackQuery, state: FSMContext):
    if not is_admin(call.from_user.id):
        return
    await state.set_state(States.broadcast_msg)
    await call.message.edit_text("📢 Mesaj yazın:", reply_markup=kb.back_menu())


@router.message(States.broadcast_msg)
async def msg_broadcast(msg: Message, state: FSMContext):
    if not is_admin(msg.from_user.id):
        return
    await state.clear()
    users = await db.get_all_users()
    sent = 0
    for u in users:
        try:
            await msg.bot.send_message(u["user_id"], f"📢 {msg.text}")
            sent += 1
        except:
            pass
    await msg.answer(f"✅ {sent} kişiye gönderildi")

... 
... @router.callback_query(F.data == "adm_give")
... async def cb_adm_give(call: CallbackQuery, state: FSMContext):
...     if not is_admin(call.from_user.id):
...         return
...     await state.set_state(States.give_balance_uid)
...     await call.message.edit_text("Kullanıcı ID:", reply_markup=kb.back_menu())
... 
... 
... @router.message(States.give_balance_uid)
... async def msg_give_uid(msg: Message, state: FSMContext):
...     if not is_admin(msg.from_user.id):
...         return
...     try:
...         uid = int(msg.text.strip())
...         user = await db.get_user(uid)
...         if not user:
...             await msg.answer("Bulunamadı")
...             return
...         await state.update_data(give_uid=uid)
...         await state.set_state(States.give_balance_amt)
...         await msg.answer(f"Mevcut: ${user.get('balance_usdt', 0):.4f}\nUSDT miktarı gir:")
...     except:
...         await msg.answer("Geçersiz ID")
... 
... 
... @router.message(States.give_balance_amt)
... async def msg_give_amt(msg: Message, state: FSMContext):
...     if not is_admin(msg.from_user.id):
...         return
...     try:
...         amount = float(msg.text.replace(",", "."))
...         data = await state.get_data()
...         uid = data["give_uid"]
...         await state.clear()
...         await db.update_balance_usdt(uid, amount)
...         await msg.answer(f"✅ ${amount:.2f} USDT eklendi")
...     except:
