Python 3.14.3 (tags/v3.14.3:323c59a, Feb  3 2026, 16:04:56) [MSC v.1944 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> """
... QR Kod Oluşturma
... """
... import qrcode
... from io import BytesIO
... 
... def generate_qr_code(data: str) -> BytesIO:
...     """
...     Verilen data için QR kod oluştur ve BytesIO olarak döndür
...     """
...     qr = qrcode.QRCode(
...         version=1,
...         error_correction=qrcode.constants.ERROR_CORRECT_L,
...         box_size=10,
...         border=4,
...     )
...     qr.add_data(data)
...     qr.make(fit=True)
... 
...     img = qr.make_image(fill_color="black", back_color="white")
... 
...     buffer = BytesIO()
...     img.save(buffer, format='PNG')
...     buffer.seek(0)
... 
